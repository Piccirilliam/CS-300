/*Name: Andrew Piccirilli
Course: CS-300
Email: andrew.piccirilli@snhu.edu
Project 2*/

#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>

// Course struct to hold course information
struct Course {
    std::string courseNum;
    std::string courseName;
    std::vector<std::string> prerequisites;

    Course() {}
    Course(const std::string& num, const std::string& name, const std::vector<std::string>& prereqs = {}) :
        courseNum(num), courseName(name), prerequisites(prereqs) {}
};

// Node struct for Binary Search Tree
struct Node {
    Course course;
    Node* left;
    Node* right;

    Node(const Course& course) : course(course), left(nullptr), right(nullptr) {}
};

// BST class
class BST {
private:
    Node* root;

    void addNode(Node* node, const Course& course);
    void inOrder(Node* node) const;
    Node* findCourse(Node* node, const std::string& courseNum) const;

public:
    BST() : root(nullptr) {}
    ~BST() { /* Implement destructor to free memory */ }

    void insert(const Course& course);
    void inOrderTraversal() const;
    void printCourse(const std::string& courseNum) const;
    bool loadData(const std::string& fileName);
};

void BST::addNode(Node* node, const Course& course) {
    if (node->course.courseNum > course.courseNum) {
        if (node->left == nullptr)
            node->left = new Node(course);
        else
            addNode(node->left, course);
    }
    else {
        if (node->right == nullptr)
            node->right = new Node(course);
        else
            addNode(node->right, course);
    }
}

void BST::insert(const Course& course) {
    if (root == nullptr)
        root = new Node(course);
    else
        addNode(root, course);
}

void BST::inOrder(Node* node) const {
    if (node != nullptr) {
        inOrder(node->left);
        std::cout << "Course Number: " << node->course.courseNum << " Course Name: " << node->course.courseName << " Prerequisites: ";
        for (const auto& prereq : node->course.prerequisites) {
            std::cout << prereq << " ";
        }
        std::cout << "\n";
        inOrder(node->right);
    }
}

void BST::inOrderTraversal() const {
    inOrder(root);
}

Node* BST::findCourse(Node* node, const std::string& courseNum) const {
    if (node == nullptr || node->course.courseNum == courseNum)
        return node;

    if (node->course.courseNum < courseNum)
        return findCourse(node->right, courseNum);

    return findCourse(node->left, courseNum);
}

void BST::printCourse(const std::string& courseNum) const {
    Node* courseNode = findCourse(root, courseNum);
    if (courseNode != nullptr) {
        std::cout << "Course Number: " << courseNode->course.courseNum << " Course Name: " << courseNode->course.courseName << " Prerequisites: ";
        for (const auto& prereq : courseNode->course.prerequisites) {
            std::cout << prereq << " ";
        }
        std::cout << "\n";
    }
    else {
        std::cout << "Course not found. Please enter a valid course number.\n";
    }
}

bool BST::loadData(const std::string& fileName) {
    std::ifstream file(fileName);
    if (!file.is_open()) {
        std::cout << "Error opening file.\n";
        return false;
    }

    std::string line;
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        std::string courseNum, courseName, prereq;
        std::vector<std::string> prerequisites;

        std::getline(iss, courseNum, ',');
        std::getline(iss, courseName, ',');

        while (std::getline(iss, prereq, ',')) {
            prerequisites.push_back(prereq);
        }

        Course course(courseNum, courseName, prerequisites);
        insert(course);
    }

    file.close();
    return true;
}

int main() {
    BST bst;
    int choice = 0;
    std::string courseNum;
    const std::string fileName = "ProjectCourseFile.txt";

    std::cout << "Welcome to the course planner!\n";

    while (choice != 4) {
        std::cout << "\n**-------------------------**\n";
        std::cout << "|           MENU            |\n";
        std::cout << "|---------------------------|\n";
        std::cout << "| [1] Load Data Structure   |\n";
        std::cout << "| [2] Print Course List     |\n";
        std::cout << "| [3] Print Course          |\n";
        std::cout << "| [4] Exit                  |\n";
        std::cout << "|---------------------------|\n";
        std::cout << "What would you like to do? ";
        std::cin >> choice;

        switch (choice) {
        case 1:
            if (bst.loadData(fileName))
                std::cout << "Data loaded successfully.\n";
            break;
        case 2:
            std::cout << "\nHere is the course list:\n";
            bst.inOrderTraversal();
            break;
        case 3:
            std::cout << "Enter the course number: ";
            std::cin >> courseNum;
            bst.printCourse(courseNum);
            break;
        case 4:
            std::cout << "\nThank you for using the course planner!\n";
            break;
        default:
            std::cout << choice << " is not a valid option. Please enter a number 1 - 4.\n";
            break;
        }
    }

    return 0;
}
